Src/main.o: ../Src/main.c \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/bootloader.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/flash.h
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/bootloader.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/flash.h:
