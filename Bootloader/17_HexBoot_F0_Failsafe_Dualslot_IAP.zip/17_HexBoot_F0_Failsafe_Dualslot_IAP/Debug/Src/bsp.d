Src/bsp.o: ../Src/bsp.c \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/bsp.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Device/ST/STM32F0xx/Include/stm32f030x8.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/core_cm0.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_version.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_compiler.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_gcc.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/bsp.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Device/ST/STM32F0xx/Include/stm32f030x8.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/core_cm0.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_version.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_compiler.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include/cmsis_gcc.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h:
