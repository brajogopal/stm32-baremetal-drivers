Src/firmware_pingpong.o: ../Src/firmware_pingpong.c \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/firmware_pingpong.h
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/firmware_pingpong.h:
