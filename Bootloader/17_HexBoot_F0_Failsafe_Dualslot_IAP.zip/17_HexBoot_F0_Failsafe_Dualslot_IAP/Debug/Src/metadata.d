Src/metadata.o: ../Src/metadata.c \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/metadata.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/flash.h \
 C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/crc.h
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/metadata.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/flash.h:
C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc/crc.h:
