################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/bootloader.c \
../Src/bsp.c \
../Src/crc.c \
../Src/delay.c \
../Src/dma.c \
../Src/firmware_pingpong.c \
../Src/firmware_receiver.c \
../Src/flash.c \
../Src/main.c \
../Src/metadata.c \
../Src/slot_manager.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/uart.c 

OBJS += \
./Src/bootloader.o \
./Src/bsp.o \
./Src/crc.o \
./Src/delay.o \
./Src/dma.o \
./Src/firmware_pingpong.o \
./Src/firmware_receiver.o \
./Src/flash.o \
./Src/main.o \
./Src/metadata.o \
./Src/slot_manager.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/uart.o 

C_DEPS += \
./Src/bootloader.d \
./Src/bsp.d \
./Src/crc.d \
./Src/delay.d \
./Src/dma.d \
./Src/firmware_pingpong.d \
./Src/firmware_receiver.d \
./Src/flash.d \
./Src/main.d \
./Src/metadata.d \
./Src/slot_manager.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/uart.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F0 -DSTM32F030C8Tx -c -I"C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/Bootloader/17_HexBoot_F0_Failsafe_Dualslot_IAP/Inc" -I"C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Device/ST/STM32F0xx/Include" -I"C:/Users/brajo/OneDrive/Desktop/Github/stm32-baremetal-drivers/chip_headers/CMSIS/Include" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/bootloader.cyclo ./Src/bootloader.d ./Src/bootloader.o ./Src/bootloader.su ./Src/bsp.cyclo ./Src/bsp.d ./Src/bsp.o ./Src/bsp.su ./Src/crc.cyclo ./Src/crc.d ./Src/crc.o ./Src/crc.su ./Src/delay.cyclo ./Src/delay.d ./Src/delay.o ./Src/delay.su ./Src/dma.cyclo ./Src/dma.d ./Src/dma.o ./Src/dma.su ./Src/firmware_pingpong.cyclo ./Src/firmware_pingpong.d ./Src/firmware_pingpong.o ./Src/firmware_pingpong.su ./Src/firmware_receiver.cyclo ./Src/firmware_receiver.d ./Src/firmware_receiver.o ./Src/firmware_receiver.su ./Src/flash.cyclo ./Src/flash.d ./Src/flash.o ./Src/flash.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/metadata.cyclo ./Src/metadata.d ./Src/metadata.o ./Src/metadata.su ./Src/slot_manager.cyclo ./Src/slot_manager.d ./Src/slot_manager.o ./Src/slot_manager.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/uart.cyclo ./Src/uart.d ./Src/uart.o ./Src/uart.su

.PHONY: clean-Src

